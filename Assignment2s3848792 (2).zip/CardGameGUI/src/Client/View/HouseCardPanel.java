package View;

import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import model.interfaces.PlayingCard;

@SuppressWarnings("serial")
public class HouseCardPanel extends JPanel{//similar to the player card panel, but displays the previous house cards always
	public MainFrame mainframe;
	public CardImageCreator CIC;
	
	public HouseCardPanel(MainFrame mainframe){
		this.mainframe = mainframe;
		this.CIC = new CardImageCreator();
		setBorder(BorderFactory.createTitledBorder("House Card Panel"));
		setLayout(new FlowLayout());
		setVisible(true);
	}
	
	public void addCard(PlayingCard card)
	{//simple method to add a card picture to the panel
		JLabel cardPicture = new JLabel();
		cardPicture.setIcon(mainframe.getHouseCardPanel().getCIC().getImage(card));
		mainframe.getHouseCardPanel().add(cardPicture);
	}

	public MainFrame getMainframe() {
		return mainframe;
	}

	public void setMainframe(MainFrame mainframe) {
		this.mainframe = mainframe;
	}

	public CardImageCreator getCIC() {
		return CIC;
	}

	public void setCIC(CardImageCreator cIC) {
		CIC = cIC;
	}
}