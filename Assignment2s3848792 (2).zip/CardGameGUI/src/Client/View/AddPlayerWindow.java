package View;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import Controller.PlayerAddAL;



@SuppressWarnings("serial")
public class AddPlayerWindow extends JDialog {//this window opens when a player presses the 'add player' button in the player panel
	//it should allow for the user to enter the details of a player, who is then added to the game.
	public JTextArea nameText;
	public JTextArea initialText;
	public JButton addPlayerButton;
	public MainFrame mainframe;
	public PlayerAddAL PALL;


		   public AddPlayerWindow(MainFrame mainframe, int idCounter)
		   {

		      this.nameText = new JTextArea("Type Player Name Here", 4, 4);
		      nameText.setBorder(getBlackBorder());
		      this.initialText = new JTextArea("Type Player Initial point here", 10,10);
		      initialText.setBorder(getBlackBorder());
		      this.addPlayerButton = new JButton("Enter player");
		      this.mainframe = mainframe;
		      this.PALL = new PlayerAddAL(mainframe, this);
		      


		      setLayout(new GridLayout(1,3,10,10));
		      nameText.setLineWrap(true);
		      initialText.setLineWrap(true);
		      add(nameText);
		      add(initialText);
		      add(addPlayerButton);
		      pack();
		      

		      
		      	setBounds(mainframe.getWidth()/2,mainframe.getHeight()/2, 600,200);
			    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			    setVisible(true);
			   			    
			    
			    addPlayerButton.addActionListener(PALL);  
			 
		   }
		   
			public Border getBlackBorder()//simple method to return a border
			{
			return BorderFactory.createLineBorder(Color.black, 2);
			}


	
	

}
