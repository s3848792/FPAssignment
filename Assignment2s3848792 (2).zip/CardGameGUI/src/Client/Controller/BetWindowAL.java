package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import View.ErrorWindow;
import View.MainFrame;
import View.PlaceBetWindow;
import model.interfaces.GameEngine;
import model.interfaces.Player;

public class BetWindowAL implements ActionListener{
	//This class is to mainly handle the functionality of a players bet
	public MainFrame mainframe;
	public PlaceBetWindow betWindow;

	public BetWindowAL(MainFrame mainframe, PlaceBetWindow betWindow) {
		//these fields allow the Listener to access the rest of the GUI
		this.mainframe = mainframe;
		this.betWindow = betWindow;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//appropriate actions if the listener is called, the only listener being the bet button in the bet window
		if(e.getSource() == betWindow.getBetButton())
		{
			try
			{
				//sets the new players bet
				((Player) mainframe.getPlayerPanel().getPlayers().getSelectedItem()).setBet(Integer.parseInt(betWindow.getBetText().getText()));
				betWindow.dispose();
				mainframe.playerPanel.cancelBet.setEnabled(true);
				//enables the deal button if all players have bet
				if(checkBetMethod(mainframe.getGameEngine()) == true)
				{
				mainframe.playerPanel.deal.setEnabled(true);
				}
				//updates the summary panel with the bet
				mainframe.getSummaryPanel().updater();
			}
			catch(NumberFormatException e1)
			{
				//ensures the data entered is a number
				new ErrorWindow("Invalid Bet Data");	
			}

		}

	}
	
	public boolean checkBetMethod(GameEngine gameEngine)
	{
		//method to check all players have placed bets
		boolean validBets = true;
		for (Player player : gameEngine.getAllPlayers())
			if (player.getBet() == 0)
			{
				validBets = false;
			}
		return validBets;
	}

}
