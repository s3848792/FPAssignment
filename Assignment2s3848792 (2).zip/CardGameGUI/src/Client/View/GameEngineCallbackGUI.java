package View;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;

import model.GameEngineImpl;
import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import view.GameEngineCallbackImpl;
import view.interfaces.GameEngineCallback;


public class GameEngineCallbackGUI implements GameEngineCallback{
	public static final Logger logger = Logger.getLogger(GameEngineCallbackImpl.class.getName());
	public GameEngine gameEngine;//fields for the implementation of the GameEngineCallbackGUI(GECGUI)
	public MainFrame mainframe;

	 
	public GameEngineCallbackGUI()
	{
		this.gameEngine = new GameEngineImpl();//creates a new game engine for each GECGUI, to avoid crossing multiple of them
		gameEngine.getShuffledHalfDeck();
		gameEngine.addGameEngineCallback(this);//adds itself to the GameEngine
		SwingUtilities.invokeLater(new Runnable()
	      {
			@Override
	         public void run()
	         {
				mainframe = new MainFrame(gameEngine);//creates a mainframe for the GUI
	         }
	      });
	}
	
	
		

		@Override
		public void nextCard(Player player, PlayingCard card, GameEngine engine) {
			mainframe.getCardPanel().getCPAL().addCard(player, card);//records the card the player was dealt to be drawn later
			

		}

		@Override
		public void bustCard(Player player, PlayingCard card, GameEngine engine) {
			
		}

		@Override
		public void result(Player player, int result, GameEngine engine) {
			engine.getPlayer(player.getPlayerId()).setResult(result);//sets the player's result
			logger.log(Level.INFO, player.getPlayerName() + " Final Result = " + result);
		}

		@Override
		public void nextHouseCard(PlayingCard card, GameEngine engine) {
			mainframe.getHouseCardPanel().addCard(card);//similar to the player, records the card drawn to the house card panel
			
		}

		@Override
		public void houseBustCard(PlayingCard card, GameEngine engine) {
		}

		@Override
		public void houseResult(int result, GameEngine engine) {
			mainframe.getStatusBarPanel().update(result);//updates the status bar panel with the house result
			mainframe.getSummaryPanel().applyWinandLoss(result);//records the players win/loss/draw
			String formPlayers = ("");
			for (Player player : engine.getAllPlayers())
			{
			formPlayers  = formPlayers + player.toString(); 
			}//String created to format all player toStrings.
			logger.log(Level.INFO, "House, final Result = " + result);
			
		}




		public GameEngine getGameEngine() {
			return gameEngine;
		}




		public void setGameEngine(GameEngine gameEngine) {
			this.gameEngine = gameEngine;
		}




		public MainFrame getMainframe() {
			return mainframe;
		}




		public void setMainframe(MainFrame mainframe) {
			this.mainframe = mainframe;
		}
		
		
}