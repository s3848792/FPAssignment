package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import View.AddPlayerWindow;
import View.ErrorWindow;
import View.MainFrame;
import model.SimplePlayer;
import model.interfaces.Player;

public class PlayerAddAL implements ActionListener{
	//implements the functionality for the AddPlayerWindow

	public MainFrame mainframe;
	public AddPlayerWindow APW;
	
	public PlayerAddAL(MainFrame mainframe, AddPlayerWindow APW)
	{
		this.mainframe = mainframe;
		this.APW = APW;
		//fields allow listener to communicate with the rest of the GUI
	}

	@Override
	public void actionPerformed(ActionEvent e) {

			try {	
				//cretaes a new player and add's it to the gameengine, and adds a reference to the jcombobox in the playerpanel
			Player mf = new SimplePlayer(String.valueOf(mainframe.playerPanel.idCounter), APW.nameText.getText(), Integer.parseInt(APW.initialText.getText()));
			mainframe.getPlayerPanel().getPlayers().addItem(mf);
			mainframe.getGameEngine().addPlayer(mf);
			APW.dispose();//closes the window
			mainframe.getPlayerPanel().setIdCounter(mainframe.getPlayerPanel().getIdCounter()+1);
			//resets specific button enabling in PlayerPanel
			mainframe.playerPanel.getDeal().setEnabled(false);
			mainframe.playerPanel.getPlaceBet().setEnabled(true);
			}
			catch(NumberFormatException e1) {
				//creates an error window if the 
				new ErrorWindow("Invalid Player Data");
			}			

	}
}
