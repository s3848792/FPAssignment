package Client;

import View.GameEngineCallbackGUI;

public class TestClient1 {
	
	public static void main(String args[])
	{
		//creates a new game engine callback GUI onject
		new GameEngineCallbackGUI();	
	}
}