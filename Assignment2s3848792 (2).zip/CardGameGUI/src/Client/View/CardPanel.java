package View;

import java.awt.FlowLayout;
import java.util.Deque;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import Controller.CardPanelAL;
import model.interfaces.Player;
import model.interfaces.PlayingCard;

@SuppressWarnings("serial")
public class CardPanel extends JPanel{
	public CardPanelAL CPAL;
	public HashMap<Player, Deque<PlayingCard>> playerCards;
	public CardImageCreator CIC;
	
	public CardPanel(MainFrame mainframe){
		this.CPAL = new CardPanelAL(mainframe);
		this.playerCards= new HashMap<Player, Deque<PlayingCard>>();//used to store info on the cards the player has been dealt in the last deal
		this.CIC = new CardImageCreator();
		setBorder(BorderFactory.createTitledBorder("Player Card Panel"));
		setLayout(new FlowLayout());
		setVisible(true);
	}

	public CardImageCreator getCIC() {
		return CIC;
	}

	public void setCIC(CardImageCreator cIC) {
		CIC = cIC;
	}

	public CardPanelAL getCPAL() {
		return CPAL;
	}

	public void setCPAL(CardPanelAL cPAL) {
		CPAL = cPAL;
	}

	public HashMap<Player, Deque<PlayingCard>> getPlayerCards() {
		return playerCards;
	}

	public void setPlayerCards(HashMap<Player, Deque<PlayingCard>> playerCards) {
		this.playerCards = playerCards;
	}
	


	
}
