package View;

import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;

import Controller.CardPanelAL;
import Controller.PlayerPanelAL;
import Controller.SummaryPanelAL;
import model.interfaces.Player;


@SuppressWarnings("serial")
public class PlayerPanel extends JPanel{
	
	public int idCounter = 1;
	public MainFrame jframe;
	public JComboBox<Player> Players;
	public JButton addPlayer;
	public JButton deal;
	public JButton placeBet;
	public JButton cancelBet;
	public JButton removePlayer;
	public PlayerPanelAL PPAL;
	public CardPanelAL CPAL;
	
	public PlayerPanel(MainFrame jframe)
		{
	      setLayout(new FlowLayout());
	      
	      this.jframe = jframe;
	      this.deal = new JButton("Deal to Players");
	      this.placeBet = new JButton("Place Bet");
	      this.cancelBet = new JButton("Cancel Bet");
	      this.addPlayer = new JButton("Add Player");
	      this.removePlayer = new JButton("Remove Player");
	      
	      this.Players = new JComboBox<Player>();
	      deal.setEnabled(false);
	      removePlayer.setEnabled(false);
	      cancelBet.setEnabled(false);
	      placeBet.setEnabled(false);

	      
	      add(deal);
	      add(placeBet);
	      add(cancelBet);
	      add(Players);
	      add(addPlayer);
	      add(removePlayer);
	      
	      setBorder(BorderFactory.createTitledBorder("Player Panel"));
	      
	      this.PPAL = new PlayerPanelAL(jframe)   ; 
	      this.CPAL = new CardPanelAL(jframe);
	      
	      addPlayer.addActionListener(PPAL);
	      Players.addActionListener(PPAL);
	      Players.addActionListener(new SummaryPanelAL(jframe));
	      Players.addActionListener(CPAL);
	      removePlayer.addActionListener(PPAL);
	      placeBet.addActionListener(PPAL);
	      cancelBet.addActionListener(PPAL);
	      deal.addActionListener(CPAL);
	      
		
	}
	
	


	
	public JComboBox<Player> getPlayers()
	{
		return Players;
	}

	public int getIdCounter() {
		return idCounter;
	}

	public void setIdCounter(int idCounter) {
		this.idCounter = idCounter;
	}

	public MainFrame getJframe() {
		return jframe;
	}

	public void setJframe(MainFrame jframe) {
		this.jframe = jframe;
	}

	public JButton getAddPlayer() {
		return addPlayer;
	}

	public void setAddPlayer(JButton addPlayer) {
		this.addPlayer = addPlayer;
	}

	public JButton getDeal() {
		return deal;
	}

	public void setDeal(JButton deal) {
		this.deal = deal;
	}

	public JButton getPlaceBet() {
		return placeBet;
	}

	public void setPlaceBet(JButton placeBet) {
		this.placeBet = placeBet;
	}

	public JButton getCancelBet() {
		return cancelBet;
	}

	public void setCancelBet(JButton cancelBet) {
		this.cancelBet = cancelBet;
	}

	public JButton getRemovePlayer() {
		return removePlayer;
	}

	public void setRemovePlayer(JButton removePlayer) {
		this.removePlayer = removePlayer;
	}

	public void setPlayers(JComboBox<Player> players) {
		Players = players;
	}
}






