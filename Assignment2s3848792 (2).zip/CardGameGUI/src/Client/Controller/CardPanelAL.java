package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.JLabel;

import View.MainFrame;
import model.interfaces.Player;
import model.interfaces.PlayingCard;

public class CardPanelAL implements ActionListener {
	//This class is to mainly handle the functionality of the players cards, as well as hold the functionality regarding the deal
	
	public MainFrame mainframe;
	
	
	public CardPanelAL(MainFrame mainframe)
	{
		//allows the listener to communicate with the rest of the GUI
		this.mainframe = mainframe;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == mainframe.getPlayerPanel().getPlayers())
		{
			//calls a custom method to update the cards shown if a different player is selected
			updateCards();
		}
		else if(e.getSource() == mainframe.getPlayerPanel().getDeal())
		{
			//specifies functionality if the deal button is pressed
			//first, clears both card panels
			mainframe.getCardPanel().removeAll();
			mainframe.getHouseCardPanel().removeAll();
			//clears information regarding players and previous deal
			mainframe.getCardPanel().getPlayerCards().clear();
			mainframe.getSummaryPanel().getWinsandlosses().clear();
			//resets certain button enables in PlayerPanel
			mainframe.getPlayerPanel().getDeal().setEnabled(false);
			mainframe.getPlayerPanel().getCancelBet().setEnabled(false);
			for (Player player : mainframe.getGameEngine().getAllPlayers())
			//sets up information regarding player cards and wins/losses for each current player
			{
				mainframe.getCardPanel().getPlayerCards().put(player, new LinkedList<PlayingCard>());
				mainframe.getSummaryPanel().getWinsandlosses().put(player, null);
			}
			new Thread()
			 {
			 @Override
			 public void run()
			 {
					for (Player player : mainframe.getGameEngine().getAllPlayers())
					{
						//deals to all players in the game engine
						mainframe.getGameEngine().dealPlayer(player, 100);
					}
					//deals to house to get results
					mainframe.getGameEngine().dealHouse(100);
//					checkZeroBet();
					updateCards();
					mainframe.getSummaryPanel().updater();		
			 }
			 }.start();

		}

	}
	
	public void addCard(Player player, PlayingCard card)
	{
		//records which cards have been dealt to a player
		mainframe.getCardPanel().getPlayerCards().get(player).add(card);
	}
	
	public void updateCards()
	{//method to be called when a player has been selected to display their previous cards
		mainframe.getCardPanel().removeAll();
		//checks that the player does have cards recorded, isn't just a new player
		if(mainframe.getCardPanel().getPlayerCards().get(mainframe.getPlayerPanel().getPlayers().getSelectedItem()) != null)
		{
		for (PlayingCard card : mainframe.getCardPanel().getPlayerCards().get(mainframe.getPlayerPanel().getPlayers().getSelectedItem()))
			{
			//creates a JLabel icon to represent each card the player has been dealt, adds it to the card panel
			JLabel cardPicture = new JLabel();
			cardPicture.setIcon(mainframe.getCardPanel().getCIC().getImage(card));
			mainframe.getCardPanel().add(cardPicture);
			}
		}
		mainframe.getCardPanel().setVisible(true);
	}
	
//	public void checkZeroBet()
//	{
//		try
//		{
//	for(Player player : mainframe.getGameEngine().getAllPlayers())
//	{
//		if (player.getPoints()==0)
//		{
//			mainframe.getGameEngine().removePlayer(player);
//			for (int i = 1; i<=mainframe.getPlayerPanel().getPlayers().getItemCount();i++)
//			{
//				if (mainframe.getPlayerPanel().getPlayers().getItemAt(i).getPlayerId()== player.getPlayerId())
//				{
//					if(mainframe.getPlayerPanel().getPlayers().getItemCount()==1)
//					{
//						mainframe.getCardPanel().removeAll();
//						mainframe.getPlayerPanel().getPlayers().removeAllItems();
//						}	
//					}
//					else
//					{
//					mainframe.getPlayerPanel().getPlayers().removeItemAt(i);
//					}
//				}
//			}
//		}
//	}
//		catch(NullPointerException e3)
//		{}
//	}

}
