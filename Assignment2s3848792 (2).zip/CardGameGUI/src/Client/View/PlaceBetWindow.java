package View;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import Controller.BetWindowAL;
import Controller.SummaryPanelAL;

@SuppressWarnings("serial")
public class PlaceBetWindow extends JDialog{
	
	public JTextArea betText;
	public JButton betButton;
	public MainFrame mainframe;
	public BetWindowAL BWAL;
	
	public PlaceBetWindow(MainFrame mainframe)
	   {

	      this.betText = new JTextArea("Enter Bet in Integer Form Here");
	      this.betButton = new JButton("Enter Bet");
	      this.mainframe = mainframe;
	      this.BWAL = new BetWindowAL(mainframe, this);

	      setLayout(new FlowLayout());
	      add(betText);
	      add(betButton);
	      pack();

	      setBounds(mainframe.getWidth()/2,mainframe.getHeight()/2, 200,100);
		  setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		  setVisible(true);
		  betButton.addActionListener(BWAL);
		  betButton.addActionListener(new SummaryPanelAL(mainframe));
		 
	   }

	public JTextArea getBetText() {
		return betText;
	}

	public void setBetText(JTextArea betText) {
		this.betText = betText;
	}

	public JButton getBetButton() {
		return betButton;
	}

	public void setBetButton(JButton betButton) {
		this.betButton = betButton;
	}

	public MainFrame getMainframe() {
		return mainframe;
	}

	public void setMainframe(MainFrame mainframe) {
		this.mainframe = mainframe;
	}

	public BetWindowAL getBWAL() {
		return BWAL;
	}

	public void setBWAL(BetWindowAL bWAL) {
		BWAL = bWAL;
	}



}
