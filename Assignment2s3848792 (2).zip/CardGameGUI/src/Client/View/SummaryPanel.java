package View;

import java.awt.Color;
import java.awt.GridLayout;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import model.interfaces.Player;

@SuppressWarnings("serial")
public class SummaryPanel extends JPanel {
	public MainFrame mainframe;
	public JLabel id;
	public JLabel name;
	public JLabel points;
	public JLabel bet;
	public JLabel result;
	public JLabel winloss;
	public HashMap<Player, Boolean> winsandlosses;
	
	public SummaryPanel(MainFrame mainframe)
	{
	      setLayout(new GridLayout(2,6,2,2));
	      
	     
	      
	      this.id = new JLabel("ID:", JLabel.CENTER);
	      id.setBorder(getBlackBorder());
	      this.name = new JLabel("Name:", JLabel.CENTER);
	      name.setBorder(getBlackBorder());
	      this.points = new JLabel("Points:", JLabel.CENTER);
	      points.setBorder(getBlackBorder());
	      this.bet = new JLabel("Bet:", JLabel.CENTER);
	      bet.setBorder(getBlackBorder());
	      this.result = new JLabel("Result:", JLabel.CENTER);
	      result.setBorder(getBlackBorder());
	      this.winloss = new JLabel("WIN/LOSS:", JLabel.CENTER);
	      winloss.setBorder(getBlackBorder());
	      this.mainframe = mainframe;
	      this.winsandlosses = new HashMap<Player, Boolean>();
	      
	      add(id);
	      add(name);
	      add(points);
	      add(bet);
	      add(result);
	      add(winloss);
	      
	      setBorder(BorderFactory.createTitledBorder("Summary Panel"));
	      setBackground(Color.white);

		
	}

	public HashMap<Player, Boolean> getWinsandlosses() {
		return winsandlosses;
	}

	public void setWinsandlosses(HashMap<Player, Boolean> winsandlosses) {
		this.winsandlosses = winsandlosses;
	}

	public MainFrame getMainframe() {
		return mainframe;
	}

	public void setMainframe(MainFrame mainframe) {
		this.mainframe = mainframe;
	}

	public JLabel getId() {
		return id;
	}

	public void setId(JLabel id) {
		this.id = id;
	}

	public JLabel getPlayerName() {
		return name;
	}

	public void setPlayerName(String name) {
		this.name.setText(name);
	}

	public JLabel getPoints() {
		return points;
	}

	public void setPoints(JLabel points) {
		this.points = points;
	}

	public JLabel getBet() {
		return bet;
	}

	public void setBet(JLabel bet) {
		this.bet = bet;
	}

	public JLabel getResult() {
		return result;
	}

	public void setResult(JLabel result) {
		this.result = result;
	}

	public JLabel getWinloss() {
		return winloss;
	}

	public void setWinloss(JLabel winloss) {
		this.winloss = winloss;
	}

	public Border getBlackBorder()
	{
	return BorderFactory.createLineBorder(Color.black, 2);
	}
	
	public void updater()
	{
		try
		{//method to update the summary panel with the details of the currently selected player.
			this.name.setText(String.format("<html>Name:<br/>%s<html>", (((Player) mainframe.playerPanel.getPlayers().getSelectedItem()).getPlayerName())));
			this.id.setText(String.format("<html>Player ID:<br/>%s<html>", (((Player) mainframe.playerPanel.getPlayers().getSelectedItem()).getPlayerId())));
			this.points.setText(String.format("<html>Points:<br/>%s<html>", (((Player) mainframe.playerPanel.getPlayers().getSelectedItem()).getPoints())));
			this.bet.setText(String.format("<html>Bet:<br/>%s<html>", (((Player) mainframe.playerPanel.getPlayers().getSelectedItem()).getBet())));
			this.result.setText(String.format("<html>Result:<br/>%s<html>", (((Player) mainframe.playerPanel.getPlayers().getSelectedItem()).getResult())));
			try
			{
				if(mainframe.getSummaryPanel().getWinsandlosses().get(mainframe.getPlayerPanel().getPlayers().getSelectedItem())==true)
				{
					this.winloss.setText("<html>WIN/LOSS:<br/>WIN<html>");	
				}
				else if(mainframe.getSummaryPanel().getWinsandlosses().get(mainframe.getPlayerPanel().getPlayers().getSelectedItem())==false)
				{
					this.winloss.setText("<html>WIN/LOSS:<br/>LOSS<html>");
				}
				else
				{
					this.winloss.setText("<html>WIN/LOSS:<br/>DRAW<html>");
				}
			}
			catch(NullPointerException e1)
			{this.winloss.setText("WIN/LOSS:");}
			this.setVisible(true);
		}
		catch(NullPointerException e2)//catches if no players are selected
		{
			this.name.setText("Name:");
			this.id.setText("ID:");
			this.points.setText("Points:");
			this.bet.setText("Bet:");
			this.result.setText("Result:");
			this.winloss.setText("WIN/LOSS");
			this.setVisible(true);	
		}
	}
	public void applyWinandLoss(int result) {//method to check and record either the win or loss of a player

			for (Player player : mainframe.getGameEngine().getAllPlayers()) 
			{
			if (player.getResult()>result)
			{
				mainframe.getSummaryPanel().getWinsandlosses().remove(player);
				mainframe.getSummaryPanel().getWinsandlosses().put(player, true);
			}
			else if	(player.getResult()<result)
			{
				mainframe.getSummaryPanel().getWinsandlosses().remove(player);
				mainframe.getSummaryPanel().getWinsandlosses().put(player, false);
			}

		}
	}


	
	

}
