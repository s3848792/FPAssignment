package model;

import model.interfaces.PlayingCard;

public class PlayingCardImpl implements PlayingCard {
	//declared playing card instance variables
	private Suit suit;
	private Value value;


	public PlayingCardImpl(Suit suit, Value value) {
		//PlayingCardimpl constructor
		super();
		this.suit = suit;
		this.value = value;
	}

	@Override
	public Suit getSuit() {
		//getter method for playing card suit
		return this.suit;
	}

	@Override
	public Value getValue() {
		//getter method for playing card value
		return this.value;
	}

	@Override
	public  int getScore() {
		//Returns an appropriate integer for a cards value
		switch(this.value)
		{
		case EIGHT:
			return 8;
		case NINE:
			return 9;
		case TEN:
			return 10;
		case JACK:
			return 10;
		case QUEEN:
			return 10;
		case KING:
			return 10;
		case ACE:
			return 11;
		default:
			return 0;
		}

	}
		


	@Override
	public boolean equals(PlayingCard card) {
		//Checks if two cards have the same suit and value
		if (this.suit == card.getSuit() && this.value == card.getValue())
		{
			return true;
		}
		else
		{
			return false;
		}
}
	
	
	@Override
	public boolean equals(Object card)
	{
		//casts the object to a card, the calls the appropriate equals method
		card = (PlayingCard)card;
		return(this.equals(card));
	}
	
	@Override
	public String toString()
	{
		//returns an appropriately formatted String of the card
		return String.format("Suit: %s, Value: %s, Score: %d", this.suit, this.value, this.getScore());
	}
	
	@Override
	public int hashCode()
	{
		//Contains a unique hash code for a given card based on suit/value
		return (suit.hashCode() * value.hashCode());
	}

}
