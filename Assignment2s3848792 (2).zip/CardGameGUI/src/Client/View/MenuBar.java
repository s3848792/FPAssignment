package View;

import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

@SuppressWarnings("serial")
public class MenuBar extends MenuItem implements ActionListener{//simpe menu bar, with only an exit action implemented
	public MainFrame mainframe;
	public MenuBar(MainFrame mainframe)
	{
		this.mainframe = mainframe;
	      JMenuBar menubar = new JMenuBar();
	      JMenu fileMenu = new JMenu("File");

	      fileMenu.setMnemonic(KeyEvent.VK_F);
	      menubar.add(fileMenu);


	      JMenuItem exitItem = new JMenuItem("Exit", KeyEvent.VK_X);
	      exitItem.addActionListener(this);
	      exitItem.setAccelerator(KeyStroke.getKeyStroke('X', InputEvent.ALT_DOWN_MASK));


	      fileMenu.addSeparator();
	      fileMenu.add(exitItem);
	      menubar.add(fileMenu);
	      mainframe.setJMenuBar(menubar);

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		mainframe.dispose();//closes the mainframe, ending the program.
		
	}
	

}
