package View;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;


@SuppressWarnings("serial")
public class StatusBarPanel extends JPanel{
	
	private JLabel statusLabel1 = new JLabel("House Result: ", JLabel.CENTER);


	   public StatusBarPanel()
	   {
	      setLayout(new GridLayout(1, 1));

	      statusLabel1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	      add(statusLabel1);

	      setBorder(BorderFactory.createTitledBorder("Status Panel"));
	   }
	   
	   public void update(int result)
	   {//simple method to update the bar with the house result.
		   statusLabel1.setText("House Result: " + result) ;
	   }

}
