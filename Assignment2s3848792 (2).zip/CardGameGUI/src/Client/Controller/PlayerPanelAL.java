package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import View.AddPlayerWindow;
import View.MainFrame;
import View.PlaceBetWindow;
import model.interfaces.Player;

public class PlayerPanelAL implements ActionListener {
	//implement functionality for the Player panel action listener which mainly concerns the Player Panel items
	
	public MainFrame mainframe;
	
	public PlayerPanelAL(MainFrame mainframe) {
		super();
		this.mainframe = mainframe;//allows the listener to communicate with the rest of the GUI
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource() == mainframe.getPlayerPanel().getAddPlayer())
		{//creates a new addPlayerWindow if the addPlayer button is pressed
		new AddPlayerWindow(mainframe, mainframe.getPlayerPanel().getIdCounter());
		}
		if (e.getSource() == mainframe.getPlayerPanel().getPlayers() && mainframe.getPlayerPanel().getPlayers().getItemCount()>=1)
		{//acts on the Player Selector being activated
			//mainly just resets specific button enabling
			mainframe.getPlayerPanel().getPlaceBet().setEnabled(true);
			mainframe.getPlayerPanel().getRemovePlayer().setEnabled(true);
			if (((Player) mainframe.getPlayerPanel().getPlayers().getSelectedItem()).getBet() == 0)
			{
				mainframe.getPlayerPanel().getCancelBet().setEnabled(false);
			}
			else if(((Player) mainframe.getPlayerPanel().getPlayers().getSelectedItem()).getBet() >= 1)
			{
				mainframe.getPlayerPanel().getCancelBet().setEnabled(true);
			}
		}
		if (e.getSource() == mainframe.getPlayerPanel().getRemovePlayer())
		{//activated when remove player button is pressed
			mainframe.getCardPanel().removeAll();//clears the card panel	
			mainframe.getGameEngine().removePlayer((Player) mainframe.getPlayerPanel().getPlayers().getSelectedItem());//removes the selected player from the game engine
			if (mainframe.getPlayerPanel().getPlayers().getItemCount() == 1)//removes all items in the Player selector if only one was present, to avoid null pointer exception
			try
			{
			{
				mainframe.getPlayerPanel().getPlayers().removeAllItems();
			}
			}
			catch(NullPointerException e1)
			{}//avoids NullPointerException locking up UI
			else
			{
				mainframe.getPlayerPanel().getPlayers().removeItem(mainframe.getPlayerPanel().getPlayers().getSelectedItem());//removes player from Player selector
			}
			mainframe.getSummaryPanel().updater();//updates summary panel with newly selected player info
			if (mainframe.getPlayerPanel().getPlayers().getItemCount()==0)
			{//resets button enabling if no players
				mainframe.getPlayerPanel().getPlaceBet().setEnabled(false);
				mainframe.getPlayerPanel().getRemovePlayer().setEnabled(false);
				mainframe.getPlayerPanel().getCancelBet().setEnabled(false);
			}
		}
		if(e.getSource() == mainframe.getPlayerPanel().getPlaceBet())
		{//opens a betting window if a bet is placed
		new PlaceBetWindow(mainframe.getPlayerPanel().getJframe());
		}
		if(e.getSource() == mainframe.getPlayerPanel().getCancelBet())
		{//resets button enabling, resets selected player's bet, then updates summary panel with new info
		mainframe.getPlayerPanel().getCancelBet().setEnabled(false);
		mainframe.getPlayerPanel().getDeal().setEnabled(false);
		((Player) mainframe.getPlayerPanel().getPlayers().getSelectedItem()).resetBet();
		mainframe.getSummaryPanel().updater();
		}
		
	}

}
