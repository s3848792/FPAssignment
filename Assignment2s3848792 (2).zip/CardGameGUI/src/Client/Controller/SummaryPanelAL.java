package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import View.MainFrame;

public class SummaryPanelAL implements ActionListener {//implements some functionality for Summary panel
	public MainFrame mainframe;
	
	public SummaryPanelAL(MainFrame mainframe)
	{//uses fields to communicate with rest of GUI
		this.mainframe = mainframe;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		mainframe.getSummaryPanel().updater();//calls the updater method in the Summary panel class
	}

	public MainFrame getMainframe() {
		return mainframe;
	}

	public void setMainframe(MainFrame mainframe) {
		this.mainframe = mainframe;
	}

}
