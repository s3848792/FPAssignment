package View;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import model.interfaces.PlayingCard;


public class CardImageCreator {//this class is used to created scaled card image icons from the project files, to be added to the card panel
	public String cardSuit;
	public String cardValue;
	public Image image;
	public BufferedImage image1;
	public static final String FILE_PATH = String.format("cards%s", File.separator);	
	public CardImageCreator()
	{
	}
	
	@SuppressWarnings("static-access")
	public ImageIcon getImage(PlayingCard card)
	{//returns an ImageIcon if the proportionally scaled card
			 cardSuit = card.getSuit().toString();
			 cardValue = card.getValue().toString();
			 image1 = new BufferedImage(100,150, BufferedImage.TYPE_INT_ARGB);//creates a new buffered image to be filled
			    try{
			      File f = new File(String.format("src/Images%s%s_%s.PNG",File.separator, cardSuit,cardValue)); 
			      image = ImageIO.read(f);//reads the file of the card picture to an Image
				Image resultingImage = image.getScaledInstance(100, 150, image.SCALE_DEFAULT);//read image is now scaled appropriately
			      image1.getGraphics().drawImage(resultingImage,0,0,null);//buffered image is now filled with the scaled card
			    }catch(IOException e){
			      System.out.println("Error: "+e);
			    }
			    ImageIcon i1 = new ImageIcon(image1);//finally, the buffered card picture is cast as an imageIcon, then returned.
			    return i1;
	}
	


}
