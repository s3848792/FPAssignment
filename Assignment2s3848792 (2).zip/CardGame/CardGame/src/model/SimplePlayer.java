package model;

import model.interfaces.Player;


public class SimplePlayer implements Player {
	
//private class fields are declared
	private String id;
	private String playerName;
	private int initialPoints;
	private int bet;
	private int result;
	
	

	public SimplePlayer(String id, String playerName, int initialPoints) {
		//constructs a player object
		super();
		this.id = id;
		this.playerName = playerName;
		this.initialPoints = initialPoints;
	}

	@Override
	public String getPlayerName() {
		//getter method for playerName attribute
		return this.playerName;
	}

	@Override
	public void setPlayerName(String playerName) {
		//setter method for playerName attribute
		this.playerName = playerName;

	}

	@Override
	public int getPoints() {
		//getter method for initialPoints attribute
		return this.initialPoints;
	}

	@Override
	public void setPoints(int points) {
		//setter method for initialPoints attribute
		this.initialPoints = points;

	}

	@Override
	public String getPlayerId() {
		//getter method for id attribute
		return this.id;
	}

	@Override
	public boolean setBet(int bet) {//setter method for initialPoints attribute
		//checks if the bet is legal, only returns true if it is
		if (bet <= initialPoints && bet >= 1)
		{
			this.bet = bet;
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public int getBet() {
		//getter method for bet attribute
		return this.bet;
	}

	@Override
	public void resetBet() {
		//sets bet to 0
		this.bet = 0;

	}

	@Override
	public int getResult() {
		//getter method for result attribute
		return this.result;
	}

	@Override
	public void setResult(int result) {
		//setter method for result attribute
		this.result = result;

	}

	@Override
	public boolean equals(Player player) {
		//checks if player id's area equal and not null, returns true if this is the case
		if (this.id == player.getPlayerId() && player.getPlayerId() != null)
			{
			return true;
			}
		else
		{
		return false;
		}
	}
	
	public boolean equals(Object player)
	{
		//casts the object as a Player, then calls the appropriate equals method
		if (this.id == ((Player) player).getPlayerId() && ((Player) player).getPlayerId() != null)
		{
		return true;
		}
	else
	{
	return false;
	}
	}

	@Override
	public int compareTo(Player player) {
		//Compares two players by their ID attribute
		return (this.id.compareTo(player.getPlayerId()));
	}
	
	
	@Override
	public int hashCode()
	{
		//generates a unique hashcode based on a player's name and id
		return(playerName.hashCode()*id.hashCode());
	}
	
	@Override
	public String toString()
	{//returns an appropriately formatted String based on the Player object.
		return String.format("Player: id=%s, name=%s, bet=%d, points=%d, RESULT .. %d \n", this.id, this.playerName, this.getBet(), this.initialPoints, this.getResult());
	}

}
