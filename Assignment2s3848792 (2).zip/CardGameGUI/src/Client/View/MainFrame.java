package View;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

import model.interfaces.GameEngine;


@SuppressWarnings("serial")
public class MainFrame extends JFrame{
	
	public GameEngine gameEngine;
	public PlayerPanel playerPanel;
	public SummaryPanel summaryPanel;
	public CardPanel cardPanel;
	public StatusBarPanel statusBarPanel;
	public HouseCardPanel houseCardPanel;
	
	public MainFrame(GameEngine gameEngine)
	   {
		super("Card Game s3848792");
		
		this.gameEngine = gameEngine;
		
	    setBounds(100, 100, 1200, 600);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setVisible(true);
	    Dimension CardPanelSize = new Dimension(400,550);
	    new MenuBar(this);
	    
	      Container gameBoardContainer = new JPanel();
	      this.playerPanel = new PlayerPanel(this);
	      this.summaryPanel = new SummaryPanel(this);
	      this.cardPanel = new CardPanel(this);
	      this.statusBarPanel = new StatusBarPanel();
	      this.houseCardPanel = new HouseCardPanel(this);
	      houseCardPanel.setPreferredSize(CardPanelSize);
	      houseCardPanel.setMinimumSize(CardPanelSize);
	      cardPanel.setPreferredSize(CardPanelSize);
	      cardPanel.setMinimumSize(CardPanelSize);
	      

	      gameBoardContainer.setLayout(new BorderLayout(4, 4));
	      gameBoardContainer.add(playerPanel, BorderLayout.NORTH);
	      gameBoardContainer.add(statusBarPanel, BorderLayout.SOUTH);
	      gameBoardContainer.add(summaryPanel, BorderLayout.EAST);
	      gameBoardContainer.add(cardPanel, BorderLayout.CENTER);
	      gameBoardContainer.add(houseCardPanel, BorderLayout.WEST);
	      add(gameBoardContainer);

		
	}
	
	public HouseCardPanel getHouseCardPanel() {
		return houseCardPanel;
	}

	public void setHouseCardPanel(HouseCardPanel houseCardPanel) {
		this.houseCardPanel = houseCardPanel;
	}

	public StatusBarPanel getStatusBarPanel() {
		return statusBarPanel;
	}

	public void setStatusBarPanel(StatusBarPanel statusBarPanel) {
		this.statusBarPanel = statusBarPanel;
	}

	public GameEngine getGameEngine()
	{
		return this.gameEngine;
		
	}

	public PlayerPanel getPlayerPanel() {
		return playerPanel;
	}

	public void setPlayerPanel(PlayerPanel playerPanel) {
		this.playerPanel = playerPanel;
	}

	public SummaryPanel getSummaryPanel() {
		return summaryPanel;
	}

	public void setSummaryPanel(SummaryPanel summaryPanel) {
		this.summaryPanel = summaryPanel;
	}

	public void setGameEngine(GameEngine gameEngine) {
		this.gameEngine = gameEngine;
	}

	public CardPanel getCardPanel() {
		return cardPanel;
	}

	public void setCardPanel(CardPanel cardPanel) {
		this.cardPanel = cardPanel;
	}

}
