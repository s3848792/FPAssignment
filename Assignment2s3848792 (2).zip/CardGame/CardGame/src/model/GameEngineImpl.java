package model;



import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Deque;

import model.interfaces.GameEngine;
import model.interfaces.Player;
import model.interfaces.PlayingCard;
import model.interfaces.PlayingCard.Suit;
import model.interfaces.PlayingCard.Value;
import view.interfaces.GameEngineCallback;

public class GameEngineImpl implements GameEngine {
	//Declaring collections as instance variables for the Game Engine.
	private ArrayList<Player> playersForGame = new ArrayList<Player>();
	private Deque<PlayingCard> deck = new LinkedList<PlayingCard>(getShuffledHalfDeck());
	private LinkedList<GameEngineCallback> callBackList = new LinkedList<GameEngineCallback>();
	
	
	
	

	@Override
	public void dealPlayer(Player player, int delay) throws IllegalArgumentException {
		int tempResult = 0;
		do
			{
			//loop calls callback on the player's next card, removes it from the deck, then checks if the deck is empty
			callBackList.getFirst().nextCard(player, deck.getFirst(), this);
			tempResult = tempResult + deck.getFirst().getScore();
			deck.removeFirst();
			if (deck.size() == 0)
			{
				deck.addAll(getShuffledHalfDeck());
			}
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			}
		while(tempResult + deck.getFirst().getScore() <= BUST_LEVEL);
		callBackList.getFirst().bustCard(player, deck.getFirst(), this);// loggers are called to record results.
		callBackList.getFirst().result(player, tempResult, this);
		player.setResult(tempResult);//player results are set	
	}

	@Override
	public void dealHouse(int delay) throws IllegalArgumentException {
		int tempResult = 0;
		do
			{
			//loop calls callback on the house's next card, removes it from the deck, then checks if the deck is empty
			callBackList.getFirst().nextHouseCard(deck.getFirst(), this);
			tempResult = tempResult + deck.getFirst().getScore();
			deck.removeFirst();
			if (deck.size() == 0)
			{
				deck.addAll(getShuffledHalfDeck());
			}
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			}
		while(tempResult + deck.getFirst().getScore() <= BUST_LEVEL);
		callBackList.getFirst().houseBustCard(deck.getFirst(), this);// loggers are called to record results.	
		for (Player player : playersForGame)//calls the applyWinLoss method on all players
		{
			applyWinLoss(player, tempResult);
		}
		callBackList.getFirst().houseResult(tempResult, this); // loggers are called to record final results.	
		for (Player player : playersForGame)
		{
			//resets all player's bets
			player.resetBet();
		}
	}

	@Override
	public void applyWinLoss(Player player, int houseResult) {
		//Appropriately subtracts and adds bet amount to player's points, depending on their result.
		if (player.getResult() > houseResult)
		{
			player.setPoints(player.getPoints() + player.getBet());
		}
		else if(player.getResult() < houseResult)
		{
			player.setPoints(player.getPoints() - player.getBet());
		}

	}

	@Override
	public void addPlayer(Player player) {
		if(player.getPlayerId() == null)//Checks if the Player has an ID
		{
			throw new IllegalArgumentException("Invalid Argument Null");
		}
		boolean idCheck = false;
		for(int i=0; i < playersForGame.size(); i++)
			if (playersForGame.get(i).equals(player))
			{
				//Searches playersForGame collection for player, then replaces them if found
				playersForGame.set(i, player);
				idCheck  = true;
			}
		if(idCheck == false)
		{
			//only adds player to collection if they don't already exist
			playersForGame.add(player);
		}
		}
	
	@Override
	public Player getPlayer(String id) {
		//Searches the instance collection playersForGame with matching id, then returns them if found
		for(int i=0; i < playersForGame.size(); i++)
			if (playersForGame.get(i).getPlayerId() == id)
			{
				return playersForGame.get(i);
			}
		return null;
	}

	@Override
	public boolean removePlayer(Player player) {
		//Checks if the p[layer exists in the instance collection playersForgame
		for(int i=0; i < playersForGame.size(); i++)
			if (playersForGame.get(i).equals(player))
			{
				//removes them if they do exist
				playersForGame.remove(i);
				return true;
			}
		//returns false if they did not exist
		return false;
	}

	@Override
	public boolean placeBet(Player player, int bet) {
		//calls the setBet method in SimplePlayerImpl
		return (player.setBet(bet));
	}

	@Override
	public void addGameEngineCallback(GameEngineCallback gameEngineCallback) {
		//adds the callback to the instance collection callBackList
		callBackList.add(gameEngineCallback);

	}

	@Override
	public boolean removeGameEngineCallback(GameEngineCallback gameEngineCallback) {
		//checks if gameEngineCallback exists in the Game Engine, then removes if it does
		if (callBackList.contains(gameEngineCallback))
		{
			callBackList.remove(gameEngineCallback);
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public Collection<Player> getAllPlayers() {
		//implements a bubble sort algorithm to sort players by ID
		Player temp;
		for (int i = 0; i<playersForGame.size();i++ )
		{
			for(int j = i+1;j<playersForGame.size(); j++ )
			{
				if (playersForGame.get(i).compareTo(playersForGame.get(j))>0)
				{
					temp = playersForGame.get(i);
					playersForGame.set(i, playersForGame.get(j));
					playersForGame.set(j, temp);
				}
			}
		}
		return playersForGame;
	}


	@Override
	public Deque<PlayingCard> getShuffledHalfDeck() {
		//creates a local Deque, fills it with playing card implementation objects, shuffles, then returns it.
		Deque<PlayingCard> deck = new LinkedList<PlayingCard>();
		{
			//nested for-loops run through all Suit and Value Enums.
			for(Suit newSuit : Suit.values())
			{
				for (Value newVal : Value.values())
				{
					deck.addFirst(new PlayingCardImpl(newSuit, newVal));
				}
			}
		}
		Collections.shuffle((List<?>) deck);//shuffles the now-populated deque
		
		return deck;
	}
	
	

}
