package View;

import java.awt.FlowLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class ErrorWindow extends JDialog{//basic error window to add usability to the project
	public ErrorWindow(String errorMessage)
	{
		this.add(new JLabel(String.format("%s", errorMessage)), JLabel.CENTER);
		setLayout(new FlowLayout());
		setBounds(200, 200, 200, 200);
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    setVisible(true);
	}

}
